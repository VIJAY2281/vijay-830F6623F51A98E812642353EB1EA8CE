#Store input numbers
num1=input('Enter first number:')
num2=input('Enter sceond number:')
           
#Add two number
sum = float(num1) + float(num2)

#Display the sum
print('The sum of{0} and {1} is {2}'.format(num1,num2,sum))